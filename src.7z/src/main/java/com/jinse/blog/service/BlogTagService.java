package com.jinse.blog.service;

import com.jinse.blog.pojo.BlogTag;

public interface BlogTagService {

	int addBlogTag(BlogTag blogTag);

}
