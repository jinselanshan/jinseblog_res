package com.jinse.blog.service.impl;

import com.jinse.blog.service.PermissionsService;

public class PermissionsServiceImpl implements PermissionsService {

}
