package com.jinse.blog.service.impl;

import com.jinse.blog.service.RoleService;

public class RoleServiceImpl implements RoleService {

}
