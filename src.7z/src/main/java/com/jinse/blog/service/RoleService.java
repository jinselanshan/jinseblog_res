package com.jinse.blog.service;

public interface RoleService {

}
