package com.jinse.blog.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.jinse.blog.service.FollowerService;


@Controller
public class FollowerController {
	private static final Logger logger = LoggerFactory.getLogger(FollowerController.class);

/*	@Autowired
	private FollowerService followerService;*/

}
