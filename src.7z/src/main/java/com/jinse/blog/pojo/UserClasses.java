package com.jinse.blog.pojo;

public class UserClasses extends User{

	private Integer isfollowing;

	public Integer getIsfollowing() {
		return isfollowing;
	}

	public void setIsfollowing(Integer isfollowing) {
		this.isfollowing = isfollowing;
	}
	
	
}
